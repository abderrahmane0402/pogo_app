import { model, Schema } from 'mongoose';


const cartebancaireSchema = new Schema({
    nomProprietaire: { type: String, required: true },
    numCarte: { type: Number, required: true, unique: true },
    cvv: { type: Number, required: true },
    dateExperation: { type: Date, required: true },
});

const utilisateurSchema = new Schema({
    nom: { type: String, required: true },
    date_creation: { type: Date, default: Date.now },
    photo: String,
    prenom: { type: String, required: true },
    email: { type: String, required: true },
    telephone: { type: Number, required: true },
    carteBancaire: [cartebancaireSchema]
});

const Utilisateur = model('Utilisateur', utilisateurSchema);

export default Utilisateur